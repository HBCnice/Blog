#include<iostream.h>
void main()
{
	int a,b;
	cout<<"Please enter the value of a"<<endl;
	cin>>a;
		if(a%3==0||a%7==0)
			cout<<"yes"<<endl;
		else
			cout<<"no"<<endl;
}